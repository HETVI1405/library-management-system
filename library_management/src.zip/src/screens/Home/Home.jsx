import { useContext } from "react";
import Navbar from "../../Components/Navbar/Navbar.jsx";
import RoutesConfig from "./../../Routes/AllRoutes.jsx";
import "./Home.css"
import { AuthorizationContext } from "../../Components/Context/ContentApi.jsx";

export default function Home() {

    const {admin} = useContext(AuthorizationContext)

    return (
        <div style={{ display: "flex", overflow: "hidden" }}>
            <div style={{ height: "100vh" }}>
                <div><Navbar /></div>
            </div>



            <div style={{ height: "100vh", width: "100%", }}>
                <div style={{ backgroundColor: "#02162bff", width: "100%", height: "60px", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0px 0px", position: "sticky", top: "0px" }}>
                    <h5 style={{ color: "white" }} >National Digital Library </h5>
                    <div className="left" style={{ color: "whitesmoke" , marginRight:"3%"}}>
                          <div className="profile">
           <i className="ri-user-settings-fill" style={{fontSize:"22px"}}></i>
            <div className="profile-info">
              <span className="admin-text" style={{fontSize:"15px"}}>{admin}</span>
              <span className="status">● Online</span>
            </div>
          </div>
                       
                         </div>
                </div>
                <div style={{ width: "100%", height: "100vh", overflow: "auto" }}><RoutesConfig /></div>
            </div>
        </div>
    )
}
