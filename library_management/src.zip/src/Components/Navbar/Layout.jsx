import { useState } from "react";
import Navbar from "../Navbar/Navbar";
import Sidebar from "../Sidebar/Sidebar";
import Dashboard from "../Dashboard/Dashboard";
import "./Layout.css";

export default function Layout() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="layout">
      {/* Navbar */}
      <Navbar onToggle={() => setCollapsed(!collapsed)} />

      <div className="main">
        {/* Sidebar */}
      

        {/* Page Content */}
        <div className={`content ${collapsed ? "collapsed" : ""}`}>
          <Dashboard />
        </div>
      </div>
    </div>
  );
}
