// import { NavLink } from "react-router-dom";
// import "./navbar.css";
// import { AuthorizationContext } from "../Context/ContentApi";
// import { useContext } from "react";

// export default function Navbar() {
//   const { admin } = useContext(AuthorizationContext);
//   const isAdmin = admin === "admin123@gmail.com";

//   const PageData = [
//     { id: 1, title: "Dashboard", path: "/", icon: "fas fa-tachometer-alt" },
//     isAdmin && { id: 2, title: "Add Book", path: "/addbook", icon: "fas fa-plus" },
//     { id: 3, title: "Books", path: "/book", icon: "fas fa-book" },
//     { id: 4, title: "Members", path: "/member", icon: "fas fa-users" },
//     { id: 5, title: "Login", path: "/login", icon: "fas fa-user" },
//   ].filter(Boolean);

//   return (
//     <div>
//       <nav className="sidebar bg-white">
//         <div className="profile-box">
//           <i className="ri-user-settings-fill"></i>
//           <div className="profile-text">
//             <span className="admin-text">Admin</span>
//             <span className="status">● Online</span>
//           </div>
//         </div>

//         <div className="sidebar-sticky">
//           <div className="list-group list-group-flush">
//             {PageData.map((el) => (
//               <NavLink
//                 key={el.id}
//                 to={el.path}
//                 className={({ isActive }) =>
//                   "list-group-item list-group-item-action py-2 ripple" +
//                   (isActive ? " active" : "")
//                 }
//               >
//                 <i className={`${el.icon} fa-fw me-3`}></i>
//                 <span>{el.title}</span>
//               </NavLink>
//             ))}
//           </div>
//         </div>
//       </nav>
//     </div>
//   );
// }
  import { useState } from "react";
import { NavLink } from "react-router-dom";
import "./navbar.css";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(true);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const PageData = [
    { id: 1, title: "Dashboard", path: "/", icon: "fas fa-tachometer-alt" },
    { id: 2, title: "Add Book", path: "/addbook", icon: "fas fa-plus" },
    { id: 3, title: "Books", path: "/book", icon: "fas fa-book" },
    { id: 4, title: "Members", path: "/member", icon: "fas fa-users" },
    { id: 5, title: "Login", path: "/login", icon: "fas fa-user" },
  ];

  return (
    <div className="layout">
      {/* Top Navbar */}
      <nav className="top-navbar">
    
        <button className="toggle-btn" onClick={toggleSidebar}>
          <i className="fas fa-bars"></i>
        </button>
      
        
        
         
      </nav>

      {/* Sidebar */}
      <aside className={`sidebar ${isOpen ? "open" : "collapsed"}`}>
        <div className="sidebar-menu">
          
     
          {PageData.map((el) => (
            <NavLink
              key={el.id}
              to={el.path}
              className={({ isActive }) =>
                "menu-item" + (isActive ? " active" : "")
              }
            >
              <i className={el.icon}></i>
              <span className="title" style={{fontSize:"18px" , margin:"-3%"}}>{el.title}</span>
            </NavLink>
          ))}
        </div>
      </aside>
    </div>
  );
}
